### My own little fork

Changes:

- Cleaned up code (typos and syntax)

- Removed THREE.Face4 support

- Added THREE.BufferGeometry support



